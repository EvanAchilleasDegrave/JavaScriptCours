class Personnage {



    constructor(nom, pointsDeVie, attaque, precision, chanceCritique, soinPotion, chanceUtiliserPotion) {
        this.nom = nom; // Nom 
        this.pointsDeVie = pointsDeVie; // Points de vie 
        this.attaque = attaque; // DMG
        this.precision = precision; // Prob. de toucher l'adversaire (0 à 1)
        this.chanceCritique = chanceCritique; // Prob. de crit (0 à 1) (dmg x2)
        this.soinPotion = soinPotion; // PV récupérés avec une potion
        this.chanceUtiliserPotion = chanceUtiliserPotion; // Prob. d'utilisé une potion
        this.aUtilisePotion = false; // Bool si le pers. a déjà utiliser la potion


    }

    // Fonctuion Attaque
    attaquer(adversaire) {
        if (this.verifierPrecision()) {
            let degats = this.attaque;
            // Vérifie si l'attaque est un coup critique
            if (this.verifierCoupCritique()) {
                degats *= 2;
                console.log(`${this.nom} réalise un coup critique !`);
            }
            console.log(`${this.nom} attaque ${adversaire.nom} et inflige ${degats} points de dégâts !`);
            adversaire.pointsDeVie -= degats; // Réduit les PV de l'ennemi
        } else {
            console.log(`${this.nom} attaque ${adversaire.nom} mais rate son coup !`);
        }
    }

    // Fonction qui vérifie la précision
    verifierPrecision() {
        const chance = Math.random(); // Génère un nombre entre 0 et 1
        return chance < this.precision;
    }

    // Fonction qui vérifie si l'attaque est un coup critique
    verifierCoupCritique() {
        const chance = Math.random(); // Génère un nombre entre 0 et 1
        return chance < this.chanceCritique;
    }

    // Fonction qui fait utiliser la potion
    tenterUtiliserPotion() {

        if (!this.aUtilisePotion && Math.random() < this.chanceUtiliserPotion) {
            this.pointsDeVie += this.soinPotion; // Augmente les PV
            this.aUtilisePotion = true; // Marque la potion comme utilisée
            console.log(`${this.nom} décide d'utiliser une potion et récupère ${this.soinPotion} points de vie !`);
            }


        else if (!this.aUtilisePotion) {

            console.log(`${this.nom} hésite mais ne décide pas d'utiliser une potion.`);

        }
    }
}

// Initialisation des pers.

const combattant1 = new Personnage("Gladiateur", 100, 15, 0.2, 0.2, 20, 0.5); // PV, DMG, PRECISION, CHANCE CRIT, VAL. POTION, CHANCE UsePotion
const combattant2 = new Personnage("Archer", 70, 10, 0.8, 0.5, 30, 0.3); // PV, DMG, PRECISION, CHANCE CRIT, VAL. POTION, CHANCE UsePotion

// Simulateur du combat 
while (combattant1.pointsDeVie > 0 && combattant2.pointsDeVie > 0) {
    console.log("\n--- Nouveau Tour ---");

    // Gladiateur attaque ou tente d'utiliser une potion si ses PV sont bas
    if (combattant1.pointsDeVie <= 15 && !combattant1.aUtilisePotion) {
        combattant1.tenterUtiliserPotion();
    } else {
        combattant1.attaquer(combattant2);
    }

    // Vérifie si l'adversaire est vaincu
    if (combattant2.pointsDeVie <= 0) {
        console.log(`\n${combattant2.nom} est vaincu ! ${combattant1.nom} remporte le combat !`);
        break;
    }

    // Gladiateur B attaque ou tente d'utiliser une potion si ses PV sont bas
    if (combattant2.pointsDeVie <= 18 && !combattant2.aUtilisePotion) {
        combattant2.tenterUtiliserPotion();
    } else {
        combattant2.attaquer(combattant1);
    }

    // Vérifie si l'adversaire est vaincu
    if (combattant1.pointsDeVie <= 0) {
        console.log(`\n${combattant1.nom} est vaincu ! ${combattant2.nom} remporte le combat !`);
        break;
    }

    // Affiche l'état des PV des deux combattants à la fin du tour
    console.log(`${combattant1.nom}: ${combattant1.pointsDeVie} PV | ${combattant2.nom}: ${combattant2.pointsDeVie} PV`);
}

console.log("\n--- Fin du Combat ---");
