// Gestion du mode clair/sombre
const toggleButton = document.getElementById('modeToggle');
const body = document.body;

// Vérification du mode 
const mode = localStorage.getItem('theme') || 'dark';
if (mode === 'light') {
    body.classList.add('light-mode');
    toggleButton.textContent = 'Mode sombre';
}

// Basculer entre les modes
toggleButton.addEventListener('click', () => {
    if (body.classList.contains('light-mode')) {
        body.classList.remove('light-mode');
        toggleButton.textContent = 'Mode clair';
        localStorage.setItem('theme', 'dark');
    } else {
        body.classList.add('light-mode');
        toggleButton.textContent = 'Mode sombre';
        localStorage.setItem('theme', 'light');
    }
});

// Gestion des Tabs
document.querySelectorAll('.tabs-nav .tab').forEach(tab => {
    tab.addEventListener('click', function () {
        // Retirer les classes actives
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('tab-active'));
        document.querySelectorAll('.content').forEach(c => c.classList.remove('active'));

        // Ajouter les classes actives au bon onglet et contenu
        this.classList.add('tab-active');
        const targetClass = this.classList[1].split('-')[1]; // Ex: 'tab-champions' -> 'champions'
        const targetContent = document.querySelector(`.content.${targetClass}-tab`);

        if (targetContent) {
            targetContent.classList.add('active');
        } else {
            console.error(`Aucun contenu trouvé pour ${targetClass}-tab`);
        }

        // Réinitialiser l'affichage des cartes si nécessaire
        if (targetClass === 'champions' || targetClass === 'collection') {
            resetCardDisplay();
        }
    });
});

// Réinitialiser l'affichage des cartes
function resetCardDisplay() {
    document.querySelectorAll('.card').forEach(card => {
        card.style.display = 'block';
    });
}

// Filtrage des cartes
function filterCards(role) {
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        if (role === 'all' || card.classList.contains(role)) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}

// Gestion du formulaire
document.getElementById('signupForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const pseudo = document.getElementById('pseudo');
    const email = document.getElementById('email');
    const password = document.getElementById('password');
    const confirmPassword = document.getElementById('confirmPassword');
    const role = document.querySelector('input[name="role"]:checked');
    const message = document.getElementById('formMessage');

    // Réinitialiser les messages d'erreur
    document.querySelectorAll('.error').forEach(el => el.style.display = 'none');
    message.textContent = '';

    let valid = true;

    // Validation du pseudo
    if (pseudo.value.length < 6) {
        document.getElementById('pseudoError').textContent = 'Le pseudo doit contenir au moins 6 caractères.';
        document.getElementById('pseudoError').style.display = 'block';
        valid = false;
    }

    // Validation de l'email
    if (!email.value.includes('@')) {
        document.getElementById('emailError').textContent = 'Veuillez entrer un email valide.';
        document.getElementById('emailError').style.display = 'block';
        valid = false;
    }

    // Validation du mot de passe
    if (password.value.length < 8 || !/[A-Z]/.test(password.value) || !/[0-9]/.test(password.value)) {
        document.getElementById('passwordError').textContent = 'Le mot de passe doit contenir au moins 8 caractères, une majuscule et un chiffre.';
        document.getElementById('passwordError').style.display = 'block';
        valid = false;
    }

    // Vérification des mots de passe
    if (password.value !== confirmPassword.value) {
        document.getElementById('confirmPasswordError').textContent = 'Les mots de passe ne correspondent pas.';
        document.getElementById('confirmPasswordError').style.display = 'block';
        valid = false;
    }

    // Validation du rôle
    if (!role) {
        document.getElementById('roleError').textContent = 'Veuillez sélectionner un rôle.';
        document.getElementById('roleError').style.display = 'block';
        valid = false;
    }

    // Afficher le message de succès
    if (valid) {
        message.textContent = 'Inscription réussie !';
        message.classList.add('success');
    }
});
